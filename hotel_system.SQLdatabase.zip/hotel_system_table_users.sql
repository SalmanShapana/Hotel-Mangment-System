
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` int(100) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `address`) VALUES
(1, 'ahmedibrahim', 123456, 'Ahmed', 'Ibrahim Ahmed', '15 may city, Cairo'),
(2, 'salmanshapna', 123, 'Salman', 'Shapana', 'Street 100, Kafr elsheikh'),
(3, 'gemy', 321, 'Mohamed', 'Gamal Khairy', 'Ismail kamel on youssef, Helwan');
