
-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_ID` varchar(100) NOT NULL,
  `employee_username` varchar(50) NOT NULL,
  `room1_reserved` varchar(20) NOT NULL,
  `room2_reserved` varchar(20) NOT NULL,
  `room3_reserved` varchar(20) NOT NULL,
  `room4_reserved` varchar(20) NOT NULL,
  `room5_reserved` varchar(20) NOT NULL,
  `room6_reserved` varchar(20) NOT NULL,
  `breakfast_service` varchar(20) NOT NULL,
  `launch_service` varchar(20) NOT NULL,
  `dinner_service` varchar(20) NOT NULL,
  `internet_service` varchar(20) NOT NULL,
  `beach_service` varchar(20) NOT NULL,
  `check_in_date` varchar(50) NOT NULL,
  `check_out_date` varchar(50) NOT NULL,
  `adults_count` int(50) NOT NULL,
  `childrens_count` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `customer_name`, `customer_ID`, `employee_username`, `room1_reserved`, `room2_reserved`, `room3_reserved`, `room4_reserved`, `room5_reserved`, `room6_reserved`, `breakfast_service`, `launch_service`, `dinner_service`, `internet_service`, `beach_service`, `check_in_date`, `check_out_date`, `adults_count`, `childrens_count`) VALUES
(42, 'Ahmed Ibrahim Ahmed', '123789123789323', 'gemy', 'True', 'False', 'False', 'False', 'False', 'True', 'True', 'False', 'False', 'False', 'False', '2022/06/05 ', '2022/06/09 ', 4, 2),
(43, 'Salman Shapana', '98989264342111322', 'gemy', 'False', 'True', 'False', 'True', 'True', 'False', 'True', 'False', 'True', 'False', 'True', '2022/06/05 ', '2022/06/26 ', 7, 4),
(44, 'Omar Hisham', '181781782566588', 'gemy', 'True', 'True', 'False', 'True', 'True', 'False', 'False', 'True', 'True', 'True', 'False', '2022/06/05 ', '2022/06/20 ', 9, 6),
(45, 'mohamd ahmed sayed', '9728372837926', 'gemy', 'False', 'False', 'False', 'False', 'True', 'True', 'True', 'True', 'True', 'False', 'False', '2022/06/05 ', '2022/06/13 ', 6, 2),
(46, 'hazem sayed ', '21213235432464567546', 'gemy', 'True', 'False', 'False', 'True', 'False', 'False', 'True', 'False', 'True', 'False', 'True', '2022/06/05 ', '2022/06/07 ', 1, 9),
(47, 'sayed sayed', '212121212', 'gemy', 'False', 'False', 'False', 'True', 'False', 'False', 'True', 'False', 'False', 'True', 'False', '2022/06/05 ', '2022/06/20 ', 32, 32);
